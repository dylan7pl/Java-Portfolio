package parImpar;

public class ParImpar {
	/*Crea una clase de prueba JUnit para verificar 
	 * que el método que implementa la lógica 
	 * esPar(int numero) funcione correctamente 
	 * para números pares e impares.
	 */

	public static Boolean esPar(int i) {
		if (i%2==0) {
			return true;
		}
		return false;
	}

}
