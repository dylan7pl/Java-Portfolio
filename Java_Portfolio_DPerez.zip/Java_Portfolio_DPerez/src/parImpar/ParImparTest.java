package parImpar;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ParImparTest {

    @Test
    void esPar_numeroPar_retornaTrue() {
        assertTrue(ParImpar.esPar(4));
    }

    @Test
    void esPar_numeroImpar_retornaFalse() {
        assertFalse(ParImpar.esPar(7));
    }

    @Test
    void esPar_numeroCero_retornaTrue() {
        assertTrue(ParImpar.esPar(0));
    }
}