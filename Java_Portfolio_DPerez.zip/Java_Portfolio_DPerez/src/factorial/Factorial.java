package factorial;


public class Factorial {
	/*Escribe pruebas unitarias para verificar el 
	 * cálculo del factorial para diferentes 
	 * entradas (0, 1, un número positivo).
	 */

	public static long calcularFactorial(int i) {
		if (i<0) throw new IllegalArgumentException("El factorial no existe para números negativos.");
		if (i==0) return 1;
		
		long resultado = 1;
        for (int j = 1; j <= i; j++) {
            resultado *= j;
        }
        return resultado;
	}
}
