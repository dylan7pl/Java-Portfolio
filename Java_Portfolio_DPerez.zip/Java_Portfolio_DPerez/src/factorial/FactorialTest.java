package factorial;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FactorialTest {

    @Test
    void calcularFactorial_cero_retornaUno() {
        assertEquals(1, Factorial.calcularFactorial(0));
    }

    @Test
    void calcularFactorial_uno_retornaUno() {
        assertEquals(1, Factorial.calcularFactorial(1));
    }

    @Test
    void calcularFactorial_positivo_retornaCorrecto() {
        assertEquals(120, Factorial.calcularFactorial(5));
    }

    @Test
    void calcularFactorial_negativo_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> Factorial.calcularFactorial(-1));
    }
}