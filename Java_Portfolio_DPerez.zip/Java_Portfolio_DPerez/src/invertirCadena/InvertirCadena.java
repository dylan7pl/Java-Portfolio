package invertirCadena;

public class InvertirCadena {

	public static String invertirCadena(String cadena) {

		if (cadena.length()==0) {
			return "";
		} else if (cadena.length()==1) {
			return cadena;
		}
		
		return new StringBuilder(cadena).reverse().toString();
	}

}
