package invertirCadena;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InvertirCadenaTest {

    @Test
    void invertirCadena_cadenaVacia_retornaVacia() {
        assertEquals("", InvertirCadena.invertirCadena(""));
    }

    @Test
    void invertirCadena_unCaracter_retornaMismoCaracter() {
        assertEquals("a", InvertirCadena.invertirCadena("a"));
    }

    @Test
    void invertirCadena_multiplesCaracteres_retornaInvertida() {
        assertEquals("edcba", InvertirCadena.invertirCadena("abcde"));
    }
}